#ifndef ERROR
#define ERROR

void error(char *m);

#endif
