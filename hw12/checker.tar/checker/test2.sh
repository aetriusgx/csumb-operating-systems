#!/bin/bash
# test 2
test $(./check <<< "0 1 0 ;") = yes
