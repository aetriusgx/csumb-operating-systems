#!/bin/bash
# test 5
test $(./check <<< "0 2 1 0 1 0 ;") = yes 
